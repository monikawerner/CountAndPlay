package com.example.android.countandplay;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        }

    int score = 0;

    private int countTheScore() {

        /**
         * Question 1
         */
        RadioButton radioButtonQuestion1Answer1 = (RadioButton) findViewById(R.id.question1_answer1);
        if (radioButtonQuestion1Answer1.isChecked()) {
            score += 1;
        }
        /**
         * Question 2
         */
        RadioButton radioButtonQuestion2Answer2 = (RadioButton) findViewById(R.id.question2_answer2);
        if (radioButtonQuestion2Answer2.isChecked()) {
            score += 1;
        }
        /**
         * Question 3
         */
        RadioButton radioButtonQuestion3Answer1 = (RadioButton) findViewById(R.id.question3_answer1);
        if (radioButtonQuestion3Answer1.isChecked()) {
            score += 1;
        }
        /**
         * Question 4
         */
        EditText editTextAnswer = (EditText) findViewById(R.id.edit_text);
        if (editTextAnswer.getText().toString().equals(getString(R.string.correct_answer)) || editTextAnswer.getText().toString().equals(getString(R.string.correct_answer_2)) || editTextAnswer.getText().toString().equals(getString(R.string.correct_answer_3))) {
            score += 2;
        }
        /**
         * Question 5
         */
        RadioButton radioButtonQuestion5Answer1 = (RadioButton) findViewById(R.id.question5_answer1);
        if (radioButtonQuestion5Answer1.isChecked()) {
            score += 1;
        }
        /**
         * Question 6
         */
        RadioButton radioButtonQuestion6Answer2 = (RadioButton) findViewById(R.id.question6_answer2);
        if (radioButtonQuestion6Answer2.isChecked()) {
            score += 1;
        }
        /**
         * Question 7
         */
        RadioButton radioButtonQuestion7Answer3 = (RadioButton) findViewById(R.id.question7_answer3);
        if (radioButtonQuestion7Answer3.isChecked()) {
            score += 1;
        }
        /**
         * Question 8
         */
        RadioButton radioButtonQuestion8Answer1 = (RadioButton) findViewById(R.id.question8_answer1);
        if (radioButtonQuestion8Answer1.isChecked()) {
            score += 1;
        }
        /**
         * Question 9
         */
        RadioButton radioButtonQuestion9Answer1 = (RadioButton) findViewById(R.id.question9_answer1);
        if (radioButtonQuestion9Answer1.isChecked()) {
            score += 1;
        }
        /**
         * Question 10
         */
        CheckBox checkBoxSentence1 = (CheckBox) findViewById(R.id.checkbox1);
        CheckBox checkBoxSentence2 = (CheckBox) findViewById(R.id.checkbox2);
        CheckBox checkBoxSentence3 = (CheckBox) findViewById(R.id.checkbox3);
        CheckBox checkBoxSentence4 = (CheckBox) findViewById(R.id.checkbox4);
        if (!checkBoxSentence1.isChecked() && checkBoxSentence2.isChecked() && checkBoxSentence3.isChecked() && !checkBoxSentence4.isChecked()) {
            score += 2;
        }

        return score;}

    public void checkTheAnswers(View view){
        score = countTheScore();
        display(score);

    }
    String myPlayerName = getIntent().getStringExtra("Player_NAME");


    private void display(int score) {

        if ( score <= 5) {
            Toast.makeText(this,myPlayerName + "!" + getString(R.string.total_score) + score + getString(R.string.you_need_practise), Toast.LENGTH_LONG).show();
        }
        if (score >= 6 && score <= 11){
            Toast.makeText(this,  myPlayerName + "!" + getString(R.string.total_score) + score + getString(R.string.good_job), Toast.LENGTH_LONG).show();
        }
        if (score == 12){
            Toast.makeText(this, myPlayerName + "!" + getString(R.string.total_score) + score + getString (R.string.excellent), Toast.LENGTH_LONG).show();
        }
    }


}

/**
        String name = getIntent().getStringExtra("key");



Intent Quiz = getIntent();
    String playerName = Quiz.getStringExtra("player_name");
*/