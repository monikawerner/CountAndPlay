package com.example.android.countandplay;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
    }

    public void startTheQuiz(View view) {
        EditText nameEditText = (EditText) findViewById(R.id.name);
        String playerName = nameEditText.getText().toString();
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("Player_NAME", playerName);
        startActivity(intent);
            }

    /**
     * Figure out the player name
     */


   }

/**
        Toast.makeText(this, "AAAA", Toast.LENGTH_SHORT).show();



 public void sendMessage(View view) {
 EditText name = findViewById(R.id.name_field);
 String playerName = name.getText().toString();
 if (TextUtils.isEmpty(name.getText())) {
 /**
 *   You can Toast a message here that the Username is Empty

            Toast.makeText(this, "We really want to know your name", Toast.LENGTH_SHORT).show();
                    name.setError("Your name is required!");
                    } else {
                    Toast.makeText(this, "Good luck " + playerName, Toast.LENGTH_SHORT).show();
                    Intent Quiz = new Intent(this, QuizActivity.class);
        startActivity(Quiz);
        }


        }

        void sendTheName ()
        Intent intent = new Intent (this, MainActivity.class);
        intent.putExtra("name","Chris");
        startActivity(intent);
    void clicked() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("key", "Monia");
        startActivity(intent);

        finish();
    }
 */




